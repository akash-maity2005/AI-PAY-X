const mongoose = require("mongoose");

const FlightSchema = new mongoose.Schema({
  from: String,
  to: String,
  date: Date,
  passengerName: String
});

module.exports = mongoose.model("Flight", FlightSchema);

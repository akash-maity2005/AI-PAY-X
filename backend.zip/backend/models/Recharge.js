const mongoose = require("mongoose");

const RechargeSchema = new mongoose.Schema({
  provider: String,
  number: String,
  amount: Number,
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Recharge", RechargeSchema);

const express = require("express");
const router = express.Router();
const Flight = require("../models/Flight");

router.post("/", async (req, res) => {
  const flight = new Flight(req.body);
  await flight.save();
  res.json({ msg: "✅ Flight booked", flight });
});

module.exports = router;

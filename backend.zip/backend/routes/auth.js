const express = require("express");
const router = express.Router();
const User = require("../models/User");

// Signup
router.post("/signup", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const user = new User({ username, email, password });
    await user.save();
    res.json({ msg: "✅ Signup successful" });
  } catch (err) {
    res.status(400).json({ msg: "❌ Error: " + err.message });
  }
});

// Login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (!user) return res.status(400).json({ msg: "❌ Invalid credentials" });
  res.json({ msg: "✅ Login successful", token: "dummy-token" });
});

module.exports = router;

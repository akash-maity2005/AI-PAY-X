const express = require("express");
const router = express.Router();
const Recharge = require("../models/Recharge");

router.post("/", async (req, res) => {
  const recharge = new Recharge(req.body);
  await recharge.save();
  res.json({ msg: "✅ Recharge successful", recharge });
});

module.exports = router;
